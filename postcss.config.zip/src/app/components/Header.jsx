"use client";
import Link from "next/link";
import { useState, useRef, useEffect } from 'react';
import { useRouter } from "next/navigation";

export default function Header() {
    const [navbar, setNavbar] = useState(false);
    const [prestationDropdown, setPrestationDropdown] = useState(false);
    const dropdownRef = useRef(null);
    const router = useRouter();

    const handleNavbarToggle = () => {
        setNavbar(!navbar);
    };

    const handlePrestationToggle = () => {
        setPrestationDropdown(!prestationDropdown);
    };

    const handleDocumentClick = (event) => {
        // Vérifier si le clic n'est pas à l'intérieur du menu Prestation
        if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
            setPrestationDropdown(false);
        }
    };

    useEffect(() => {
        document.addEventListener("click", handleDocumentClick);

        return () => {
            document.removeEventListener("click", handleDocumentClick);
        };
    }, []);

    useEffect(() => {
        setPrestationDropdown(false);
    }, [router.pathname]);

    



    useEffect(() => {
        document.addEventListener("click", handleDocumentClick);

        return () => {
            document.removeEventListener("click", handleDocumentClick);
        };
    }, []);

    useEffect(() => {
        setPrestationDropdown(false);
    }, [router.pathname]);
    return (
        <nav className="bg-white border-gray-200 dark:bg-gray-900 text-xl">
            <div className="flex flex-wrap items-center justify-between mx-auto pt-1 p-3">
                <Link href="/" className="flex items-center self-center text-2xl pl-5 pt-2 font-semibold whitespace-nowrap dark:text-white">
                    <img width={100} src="https://cdn.discordapp.com/attachments/878674914268311625/1195418856668266528/image.png?ex=65b3eb91&is=65a17691&hm=bf852bf79d570aebb383f416bf9c57167c7675110a6dae0d9d365a6e5f2ae4e7&" alt="Logo" />
                </Link>

                <button data-collapse-toggle="navbar-default" type="button" className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false" onClick={() => setNavbar(!navbar)}>
                    <span className="sr-only">Open main menu</span>
                    <svg className="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7"></path>
                    </svg>
                </button>

                <div className={`w-full md:w-auto md:block ${navbar ? 'block' : 'hidden'} pr-5`} id="navbar-default">
                    <div className="font-medium text-lg flex flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg md:flex-row md:space-x-8 md:mt-0 md:border-0 dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                        <Link href="/produits" className="block underline py-2 pl-3 pr-4 text-gray-900 rounded hover:font-bold md:hover:text-bleuvba md:p-0 dark:text-white md:dark:hover:text-indigo-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">
                            Produits
                        </Link>

                        <div
                            ref={dropdownRef}
                            className="relative group"
                            
                        >
                            <button
                                onClick={handlePrestationToggle}
                                className="block py-2 pl-3 pr-4 underline text-gray-900 rounded hover:font-bold md:hover:text-bleuvba md:p-0 dark:text-white md:dark:hover:text-indigo-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent"
                            >
                                Prestation
                            </button>

                            {prestationDropdown && (
                                <div className="absolute mt-2  bg-white/90 border rounded-md shadow-lg dark:bg-gray-800 dark:border-gray-700 dark:text-white z-40">
                                    <Link href="/prestations/programmation" className="hover:text-bleuvba block p-4 py-2">
                                        Programmation
                                    </Link>
                                    <Link href="/prestations/installation" className="hover:text-bleuvba block p-4 py-2">
                                        Installation
                                    </Link>
                                    
                                </div>
                            )}
                        </div>

                        <Link href="/aide-en-ligne" className="block underline py-2 pl-3 pr-4 text-gray-900 rounded hover:font-bold md:hover:text-bleuvba md:p-0 dark:text-white md:dark:hover:text-indigo-500 dark:hover
:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">
                            Aide en ligne
                        </Link>

                        <Link href="/contact" className="block underline py-2 pl-3 pr-4 text-gray-900 rounded hover:font-bold md:hover:text-bleuvba md:p-0 dark:text-white md:dark:hover:text-indigo-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">
                            Contact
                        </Link>
                    </div>
                </div>
            </div>
        </nav>
    )
}
