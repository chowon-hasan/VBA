"use client";
import Link from "next/link";

export default function Produits() {
  return (
    <div className="relative">
      {/* Image d'arrière-plan */}
      <img
        className="bg-cover bg-center bg-no-repeat absolute opacity-50 w-full h-full z-0 object-cover"
        src="https://cdn.discordapp.com/attachments/878674914268311625/1194645998782398474/AdobeStock_597013033.jpeg?ex=65b11bc9&is=659ea6c9&hm=c48f104a9e1edc079b507e4127de4bbf3f7a3148c7ba2e4f26ed3ac43bc36860&"
      ></img>
      {/* Texte au-dessus de l'image */}
      <main className="flex  flex-col lg:p-8 md:p-4 p-2 z-20 relative">
        <div className="text-center bg-orangevba/80 mx-36 text-4xl px-0 rounded-xl py-3 mb-15 md:mb-8 font-bold text-white">
          Trouvez ici votre calculateur de BVA pour  Renault - Ford - Mercedes  <br /> Vérifiez la disponibilité :
        </div>
        <div className="flex flex-wrap min-h-screen justify-center gap-6">
          {/* Produits */}
          <div
              className="group rounded-xl shadow-2xl w-max justify-center pt-5   transition-colors border-8 bg-white/90   border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex  mb-3  justify-center">
                <h2 className={`mt-3 text-2xl font-semibold text-center transition-transform `}>
                  Renault Captur
                </h2>
              </div>
              <div className="px-3 pb-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/essence-2009-2015/renault-captur" className="hover:underline hover:text-orangevba"><h2>1.5 essence de 2009 à 2015</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-2009-2015/renault-captur"><h2>1.2 diesel de 2009 à 2015</h2></a>
                </div>
                <div className="flex justify-center space-x-2">
                  <a href="/produits/essence-a-partir-de-2016/renault-captur" className="hover:underline  hover:text-orangevba"><h2>1.5 essence à partir de 2016</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-a-partir-de-2016/renault-captur"><h2>1.2 diesel à partir de 2016</h2></a> 
                </div>
              </div>
            </div>

            {/* Produit 2 */}
            <div
              className="group rounded-xl shadow-2xl w-max justify-center pt-5  transition-colors border-8 bg-white/90 hover:border-orangevba/110  border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex  mb-3  justify-center">
                <h2 className={`mt-3 text-2xl font-semibold text-center transition-transform `}>
                  Renault Clio IV
                </h2>
              </div>
              <p className="px-3 pb-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/essence-2009-2015/renault-clioiv" className="hover:underline hover:text-orangevba"><h2>1.5 essence de 2009 à 2015</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-2009-2015/renault-clioiv"><h2>1.2 diesel de 2009 à 2015</h2></a>
                </div>
                <div className="flex justify-center space-x-2">
                  <a href="/produits/essence-a-partir-de-2016/renault-clioiv" className="hover:underline  hover:text-orangevba"><h2>1.5 essence à partir de 2016</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-a-partir-de-2016/renault-clioiv"><h2>1.2 diesel à partir de 2016</h2></a>
                </div>
              </p>
            </div>
            {/* Produit 3 */}
            <div
              className="group rounded-xl shadow-2xl w-max justify-center pt-5  transition-colors border-8 bg-white/90 hover:border-orangevba/110  border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex  mb-3  justify-center">
                <h2 className={`mt-3 text-2xl font-semibold text-center transition-transform `}>
                  Renault Mégane
                </h2>
              </div>
              <p className="px-3 pb-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/essence-2009-2015/renault-megane" className="hover:underline hover:text-orangevba"><h2>1.5 essence de 2009 à 2015</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-2009-2015/renault-megane"><h2>1.2 diesel de 2009 à 2015</h2></a>
                </div>
                <div className="flex justify-center space-x-2">
                  <a href="/produits/essence-a-partir-de-2016/renault-megane" className="hover:underline  hover:text-orangevba"><h2>1.5 essence à partir de 2016</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-a-partir-de-2016/renault-megane"><h2>1.2 diesel à partir de 2016</h2></a>
                </div>
              </p>
            </div>

            {/* Produit 4 */}
            <div
              className="group rounded-xl shadow-2xl w-max justify-center pt-5  transition-colors border-8 bg-white/90 hover:border-orangevba/110  border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex  mb-3  justify-center">
                <h2 className={`mt-3 text-2xl font-semibold text-center transition-transform `}>
                  Renault Scénic
                </h2>
              </div>
              <p className="px-3 pb-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/essence-2009-2015/renault-scenic" className="hover:underline hover:text-orangevba"><h2>1.5 essence de 2009 à 2015</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-2009-2015/renault-scenic"><h2>1.2 diesel de 2009 à 2015</h2></a>
                </div>
                <div className="flex justify-center space-x-2">
                  <a href="/produits/essence-a-partir-de-2016/renault-scenic" className="hover:underline  hover:text-orangevba"><h2>1.5 essence à partir de 2016</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-a-partir-de-2016/renault-scenic"><h2>1.2 diesel à partir de 2016</h2></a>
                </div>
              </p>
            </div>

            {/* Produit 5 */}
            <div
              className="group rounded-xl shadow-2xl w-max justify-center pt-5   transition-colors border-8 bg-white/90 hover:border-orangevba/110  border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex  mb-3  justify-center">
                <h2 className={`mt-3 text-2xl font-semibold text-center transition-transform `}>
                  Renault Fluence
                </h2>
              </div>
              <p className="px-3 pb-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/essence-2009-2015/renault-fluence" className="hover:underline hover:text-orangevba"><h2>1.5 essence de 2009 à 2015</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-2009-2015/renault-fluence"><h2>1.2 diesel de 2009 à 2015</h2></a>
                </div>
                <div className="flex justify-center space-x-2">
                  <a href="/produits/essence-a-partir-de-2016/renault-fluence" className="hover:underline  hover:text-orangevba"><h2>1.5 essence à partir de 2016</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-a-partir-de-2016/renault-fluence"><h2>1.2 diesel à partir de 2016</h2></a>
                </div>
              </p>
            </div>

            <div
              className="group rounded-xl shadow-2xl w-max justify-center pt-5  transition-colors border-8 bg-white/90 hover:border-orangevba/110  border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex  mb-3  justify-center">
                <h2 className={`mt-3 text-2xl font-semibold text-center transition-transform `}>
                  Ford Focus
                </h2>
              </div>
              <p className="px-3 pb-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/essence-2009-2015/ford-focus" className="hover:underline hover:text-orangevba"><h2>1.5 essence de 2009 à 2015</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-2009-2015/ford-focus"><h2>1.2 diesel de 2009 à 2015</h2></a>
                </div>
                <div className="flex justify-center space-x-2">
                  <a href="/produits/essence-a-partir-de-2016/ford-focus" className="hover:underline  hover:text-orangevba"><h2>1.5 essence à partir de 2016</h2></a> <p>|</p>
                  <a className="hover:underline hover:text-orangevba" href="/produits/diesel-a-partir-de-2016/ford-focus"><h2>1.2 diesel à partir de 2016</h2></a>
                </div>
              </p>
            </div>

            <div
              className="group rounded-xl shadow-2xl w-max justify-center items-center   transition-colors border-8 bg-white/90 hover:border-orangevba/110  border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex    justify-center">
                <h2 className={`mt-3 mb-3 text-2xl   font-semibold text-center transition-transform `}>
                  Mercedes Class A
                </h2>
              </div>
              <p className="px-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/2006-2011/mercedes-class-a" className="hover:underline  hover:text-orangevba">De 2006 à 2011</a>
                </div>
                
              </p>
            </div>

            <div
              className="group rounded-xl shadow-2xl w-max justify-center   transition-colors border-8 bg-white/90 hover:border-orangevba/110  border-orangevba relative"
            >
              <img
                src="https://cdn.discordapp.com/attachments/878674914268311625/1195467343338414080/image-removebg-preview_2.png?ex=65b418b9&is=65a1a3b9&hm=ad53e7617b50737997033def5eef3070494854056e293870a4cc49d931461640&" // Remplacez par le bon chemin de l'image
                alt="Calculateur avec carton"
                className="w-full h-60 object-cover  rounded-t-xl"
                loading="lazy"
              />
              <div className="flex  mb-3  justify-center">
                <h2 className={`mt-3 text-2xl font-semibold text-center transition-transform `}>
                  Mercedes Class B
                </h2>
              </div>
              <p className="px-3 pb-3 ">
                <div className="flex justify-center space-x-2 ">
                  <a href="/produits/2006-2011/mercedes-class-b" className="hover:underline hover:text-orangevba">De 2006 à 2011</a>
                </div>
                
              </p>
            </div>
        </div>
      </main>
    </div>
  );
}
