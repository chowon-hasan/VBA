"use client"
import { useState } from 'react';
import Head from 'next/head';

const MiseEnLigne = () => {

  <Head>
  <title>Aide en ligne pour les codes défault pour les boîte automatique Renault</title>
  </Head>

    const MAX_RESULTS = 20;

    const initialCodes = [
        { code: "DTC940811", description: "Circuit temoin . Court-circuit à la masse", aide: "Vérifier l'état de la batterie" },
        { code: "DTC1525F3", description: "Incohérences information multiplexées pour rv/lv/Régulateur vitesse non conforme", aide: "Vérifier l'état de la batterie" },
        { code: "DTC174301", description: "Circuit moteur embrayage 1. Panne electrique non identifiée. Problème sur le calculateur", aide: "Vérifier l'état de la batterie + peut être problème calculateur" },
        { code: "DTC174311", description: "Circuit moteur embrayage 1. Court-circuit à la masse", aide: "Vérifier l'état de la batterie + peut être problème calculateur" },
        { code: "DTC174401", description: "Circuit moteur embrayage 2. Panne eléctrique non identifiée", aide: "Vérifier l'état de la batterie + peut être problème calculateur" },
        { code: "DTC174411", description: "Circuit moteur embrayage 2. Court-circuit à la masse", aide: "Vérifier l'état de la batterie + peut être problème calculateur" },
        { code: "DTC17441C", description: "Circuit moteur embrayage 2 problème calculateur et/ou embrayage", aide: "" },
        { code: "DTC180401", description: "Tension alimentation calculateur/ Mauvaise tension batterie", aide: "Vérifier l'état de la batterie + peut être problème calculateur" },
        { code: "DTC180714", description: "Circuit contacteur position levier. Circuit ouvert ou court-circuit à la masse.", aide: "Vérifier l'état de la batterie + effectuer un calibrage du sélecteur + vérifier le programme" },
        { code: "DTC180962", description: "Circuit contacteur position levier. Signal constant.", aide: "Vérifier l'état de la batterie + effectuer un calibrage du sélecteur + vérifier le programme" },
        { code: "DTC181516", description: "Tension batterie 12v. Basse tension", aide: "Vérifier l'état de la batterie" },
        { code: "DTC183892", description: "Tambour de selection de vitesse 1. Signal hors limite basse ou haute", aide: "Vérifier l'état de la batterie + peut être problème calculateur" },
        { code: "DTC185111", description: "Signal moteur embrayage 2. Court circuit à la masse", aide: "Problème calculateur" },
        { code: "DTC185562", description: "Signal moteur embrayage 2. Signal non plausible", aide: "Problème calculateur" },
        { code: "DTC185764", description: "Moteur embrayage 2. Incohérence signal", aide: "Problème calculateur" },
        { code: "DTC187298", description: "Embrayage 2. Température mesurée trop forte", aide: "Problème calculateur et/ou embrayage" },
        { code: "DTC189311", description: "Drum 2 moteur. Court circuit à la masse", aide: "Problème calculateur" },
        { code: "DTC189412", description: "Circuit moteur tambour de selection vitesse 1. Court-circuit au + 12 volts", aide: "Problème calculateur" },
        { code: "DTC191211", description: "Circuit capteur regime entrée 1 boite. Court-circuit à la masse", aide: "Problème calculateur. Contrôler le programme de la boite automatique" },
        { code: "DTC191311", description: "Circuit capteur régime entrée 2 boite. Court circuit à la masse", aide: "Problème calculateur. Contrôler le programme de la boite automatique" },
        { code: "DTC404086", description: "Info multiplexée pédale de frein uch invalide. Contacteur de frein invalide", aide: "Vérifier l'état de la batterie + capteur de pédale de frein" },
        { code: "DTC500886", description: "Information multiplexée temerature exterieure. Incohérence du signal", aide: "Vérifier l'état de la batterie + capteur de température" },
        { code: "DTC500887", description: "Information multiplexée temperatere exterieure. Absence de signal", aide: "Vérifier l'état de la batterie + capteur de température" },
        { code: "DTCAAAB47", description: "Calculateur. Anomalie électronique interne", aide: "Problème calculateur. Contrôler le programme de la boite automatique. Effectuer un calibrage." },
        { code: "DTCAAB047", description: "Panne electrique interne", aide: "Problème calculateur. Contrôler le programme de la boite automatique" },
        { code: "DTCC41787", description: "Information multiplexée contact frein secondaire", aide: "Vérifier l'état de la batterie + Capteur de pédale de frein" },
        { code: "DTCD22186", description: "Signal multiplexe roue avant gauche.", aide: "Vérifier l'état de la batterie + peut être problème calculateur" },
        { code: "DTCD22086", description: "Signal multiplexe roue avant droite.", aide: "Incohérence signal vérifier l'état de la batterie + peut être problème calculateur" },
    ];

    const generateH2Tags = () => {
      return initialCodes.map((code, index) => (
        <h2 key={index}>{code.code}</h2>
      ));
    };

    const [searchTerm, setSearchTerm] = useState('');
    const [filteredCodes, setFilteredCodes] = useState([]);

    const handleSearch = () => {
        const searchTermLowerCase = searchTerm.toLowerCase();
        const filtered = initialCodes.filter(code =>
            code.code.toLowerCase().includes(searchTermLowerCase) ||
            code.description.toLowerCase().includes(searchTermLowerCase) ||
            code.aide.toLowerCase().includes(searchTermLowerCase)
        ).slice(0, MAX_RESULTS);  // Limiter le nombre de résultats affichés
        setFilteredCodes(filtered);
    };

    const handleChange = (e) => {
        setSearchTerm(e.target.value);
        handleSearch(); // Appeler la fonction de recherche à chaque modification de la saisie
    };

    const [selectedCode, setSelectedCode] = useState(null); // Ajout d'un nouvel état

    // Fonction pour gérer le clic sur la recommandation
    const toggleRecommendation = (code) => {
        setSelectedCode(selectedCode === code ? null : code); // Basculer l'affichage de la recommandation
    };

    return (
        <>
          {/* Conteneur principal */}
          <div className="bg-gray-200 min-h-screen lg:min-h-[calc(100vh-48px)] items-center text-xl flex flex-col lg:flex-row relative">
    
            {/* Configuration de la page */}
            <Head>
              <title>Aide en ligne - Boîte de vitesse à contrôler</title>
            </Head>
    
            {/* Image en arrière-plan */}
            <img
              className="bg-cover bg-center absolute w-full h-full z-0 object-cover opacity-90"
src='https://cdn.discordapp.com/attachments/878674914268311625/1197182392851497030/WhatsApp_Image_2024-01-17_a_14.53.47_9a2fd1f7.jpg?ex=65ba55fd&is=65a7e0fd&hm=ce83a0684225380eb5f82eda396e7d17c20deb0ef3776e0d174eace885c91da9&'              alt="Background"
            />
            <h2 className="absolute hidden sm:block lg:block xl:block 2xl:block  mt-8  p-4 rounded-2xl bg-white/80 text-black top-0 left-1/2 transform -translate-x-1/2 text-3xl font-semibold  text-center">Aide en ligne - Boîte de vitesse à contrôler</h2>
    
            {/* Partie gauche - Texte initial */}
            <div className="flex-1 px-4 z-20  sm:pt-10 lg:ml-16 items-center mt-16 flex-col justify-center">
              <div className="border-4 border-orangevba bg-white/80 border p-4 mt-8 mb-8 rounded-lg shadow-xl text-gray-900  max-w-lg">
                <p className="mb-6 ">
                  Les boîtes automatiques (modèles DC4 et 6DCT250) couramment installées dans les véhicules <a className='font-bold cursor-text' href="/produit"> Renault Captur, Mégane, Scénic, Clio 4, Fluence </a> se composent principalement :
                </p>
    
                <ul className="list-disc pl-6  mb-6">
                  <li>d’un <a className='font-semibold cursor-text' >double embrayage à sec.</a> </li>
                  <li>d’un <a  className='font-semibold cursor-text' >volant moteur.</a></li>
                  <li>de <a className='font-semibold cursor-text' >synchros</a> </li>
                  <li>d'un <a className='font-semibold cursor-text' >calculateur.</a> </li>
                </ul>
    
                <p className="mb-6">
                  Nous avons observé que les calculateurs de ces modèles peuvent présenter des défaillances en dessous de <a className='font-bold underline cursor-text'>120 000 km</a> . De plus, il est fréquent que le double embrayage et le volant moteur commencent à montrer des signes d'usure à partir de <a className='font-bold underline cursor-text'>150 000 km</a>. Pour anticiper et résoudre ces problèmes, nous pouvons <a className='font-bold underline cursor-text' >vérifier l'état précis de l'embrayage</a>  grâce à un équipement de diagnostic spécialisé.
                </p>
              </div>
            </div>
    
            {/* Partie droite - Barre de recherche et résultats */}
<div className={`flex-3 z-20  lg:mr-0`}>
  {/* Barre de recherche */}
  <div className="">
    <p className='bg-white/95 items-center text-center border border-4 border-orangevba mr-8   mx-auto p-2 mb-4'>Rechercher code erreur ou description: </p>
    <div className="flex items-center justify-center">
      <input
        type="text"
        placeholder="Code erreur ou description"
        value={searchTerm}
        onChange={handleChange}
        className="p-2 border border-gray-300 rounded mb-56 max-w-md"
      />
      <button onClick={handleSearch} className="bg-orangevba mb-56 mr-8 hover:brightness-110 text-white  px-4 p-2 rounded ml-2">Rechercher</button>
    </div>
  </div>
    
              {/* Résultats de la recherche */}
              {searchTerm.length >= 3 && (
    <div className="bg-white/95 p-4 rounded-lg shadow-xl mt-6 text-lg overflow-y-auto max-h-[calc(100vh-256px)]">
    {filteredCodes.length > 0 ? (
                <div>
                  {/* Affichage des codes filtrés */}
                  {filteredCodes.map(code => (
                    <div key={code.code} className="mb-6 p-4 border-4 border-orangevba">
                      <p className="font-bold text-xl mb-2">{code.code}</p>
                      <p className="mb-2">{code.description}</p>
                      
                        <a href="#" className='text-orangevba font-semibold' onClick={() => toggleRecommendation(code.code)}>Recommendation</a>
                        {selectedCode === code.code && <span className='text-orangevba font-semibold'>: <br />{code.aide}</span>}
                          <p className="mt-5">
                            Pour plus d'informations, merci de nous contacter
                            <a href='/contact' className="ml-2 bg-orangevba text-white hover:brightness-110 p-2 rounded">Nous contacter</a>
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    // Aucun code trouvé
                    <div className="text-center">
                      <p className="text-2xl font-bold mb-2">CODE DÉFAUT INCONNU</p>
                      <p>Le code défaut saisi est inconnu</p>
                      <p className="mb-4">Pour plus d'informations, merci de nous contacter</p>
                      <a href='/contact' className="bg-orangevba  text-white p-2 rounded hover:brightness-110">Nous contacter</a>
                      {generateH2Tags()}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </>
      );
    };
    
    export default MiseEnLigne;