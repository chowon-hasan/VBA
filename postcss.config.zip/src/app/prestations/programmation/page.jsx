// laboiteautomatique.com/src/app/clonage.js
"use client";
import Link from "next/link";

export default function Clonage() {
  return (
    <div className="relative">
      <Head>
        <title>Programmation et clonage de votre Calculateur de boîte automatiques Renault </title>
      </Head>
      {/* Image d'arrière-plan */}
      <img
        className="bg-cover bg-center bg-no-repeat absolute w-full h-full z-0 object-cover opacity-90"
        src="https://cdn.discordapp.com/attachments/878674914268311625/1195473118274261096/AdobeStock_637408108.jpeg?ex=65b41e1a&is=65a1a91a&hm=c09850f5bcef92c19e50c2489c61290584291eb65b6f15f543ec0047e132855d&"
        alt="Background"
      />
      {/* Texte au-dessus de l'image */}
      <main className="flex min-h-screen items-center lg:p-8 sm:p-5 md-8 justify-center relative text-black">
        <div className="bg-white/95 border-8 border-orangevba rounded-2xl p-8 lg:max-w-xl text-center">
          <p className="text-4xl pb-4 font-bold">
            Services de Programmation
          </p>
          <div className="mb-8 text-lg">
            <p>
              Nous proposons des services de reprogrammation et de clonage de
              calculateurs pour boîtes automatiques avec la valise constructeur
              pour les modèles de véhicules suivants :
            </p>
            <ul className="list-disc list-inside italic font-bold mt-4">
              <p>Renault Captur | Renault Mégane | Renault Clio IV | Renault Scenic | Ford Focus | Mercedes Class A - B </p>
            </ul>
          </div>
          <p className="mb-4 text-lg">
            Références compatible :
          </p>
          <div className="flex justify-center">
            <div className="w-full italic text-sm text-gray-500 md:w-1/2 pr-4">
              <p>310320749R - A4539006303</p>
              <p>310320891R - 310321150R</p>
              <p>310320756R - 310321706R</p>
              <p>310321109R - 310321716R</p>
              <p>310321488R - 310321421R</p>
              <p>310321517R - 310321808R</p>

            </div>
          </div>
          <p className="mt-8 mb-8 text-lg">
            Avec notre expertise, nous sommes en mesure d’effectuer la
            reprogrammation ou le clonage de votre calculateur. Intervention - Livraison sur
            toute la France. <br />Pour le démontage ou l'installation du module de commande, celui ce fait uniquement en IDF ou en région voisine.
          </p>
          <a className="bg-orangevba px-3 py-2 font-semibold hover:brightness-110 text-white rounded-xl text-2xl " href="/prestations/installation">Contactez-nous</a>
        </div>
      </main>
    </div>
  );
}
