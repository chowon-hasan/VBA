"use client"
import Head from 'next/head';
import { useRouter } from 'next/navigation';





<link rel="icon" href="/favicon.ico" sizes="any" />


const Home = () => {

  const router = useRouter();

  const produits = () => {
    router.push('/produits');
  };
  const aide = () => {
    router.push('/aide-en-ligne');
  };

  return (
    <div className="relative min-h-screen flex items-center text-center text-white	 justify-center">
      <Head>
        <title>Fournisseur de Calculateur de boîte automatiques Renault et Reprogrammation</title>

      </Head>

      <video
        autoPlay
        loop
        muted
        className="absolute  object-cover opacity-80 w-full h-full z-0"
      >
        <source src="/images/videohome2.mp4" type="video/mp4" />
      </video>

      <div className="z-20 text-center">
        <h1 className="text-5xl font-semibold text-gray-500 bg-white/80 p-2 rounded mx-5 mb-7">
          Calculateur - Reprogrammation - Boites automatiques <br /> Calculateurs  Renault - Ford pour  modèles suivants :
        </h1>
        <div className='text-3xl font-semibold  text-gray-500 flex flex-col  rounded mb-10 '>
          <div className='bg-white/80 rounded p-4 ' >
            <a href='/produit' className=' p-2   hover:text-bleuvba'>Renault Captur -</a>
            <a href='/produit' className=' p-2  hover:text-bleuvba'>Renault Megane -</a>
            <a href='/produit' className=' p-2   hover:text-bleuvba'>Renault Clio IV -</a>
            <a href='/produit' className='  p-2 hover:text-bleuvba'>Renault Scenic -</a>
            <a href='/produit' className='  p-2   hover:text-bleuvba'>Renault Fluence -</a>
            <a href='/produit' className='  p-2  hover:text-bleuvba'>Ford Focus</a>
          </div>
        </div>

        <button onClick={produits} className="bg-orangevba  px-6 py-3 rounded-full font-bold hover:brightness-110">
          VERIFIER LA DISPONIBILITE
        </button>
        <div>
          <button onClick={aide} className="bg-blue-500 mt-5 px-20 py-3 rounded-full font-bold hover:brightness-110">
            AIDE EN LIGNE
          </button>
          <h2 className='sr-only'>Calculateur de Boites automatiques Renault Captur</h2>
          <h2 className='sr-only'>Calculateur de Boites automatiques Renault Megane</h2>
          <h2 className='sr-only'>Calculateur de Boites automatiques Renault Clio IV</h2>
          <h2 className='sr-only'>Calculateur de Boites automatiques Renault Scenic</h2>
          <h2 className='sr-only'>Calculateur de Boites automatiques Renault Fluence</h2>
          <h2 className='sr-only'>Calculateur de Boites automatiques Renault Focus</h2>
          <h3 className='sr-only'>310320749R 310320891R 310320756R 310321109R 310321488R 310321517R 310320841R 310320717R 310320892R 310320721R 310321520R 310321561R, A4539006303 310321808R 310321150R 310321421R 310321706R 310321716R 310321793R 310321662R 310321524R 310321994R 310322059R 310F93913R 310321149R 310321306R 310320553R 310321359R SP03241, DC4016, 310321148R, 310321488R</h3>

        </div>

      </div>
    </div>
  );
};

export default Home;
